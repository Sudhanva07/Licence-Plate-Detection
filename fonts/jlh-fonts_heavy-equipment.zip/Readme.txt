Heavy Equipment Font

The Heavy Equipment font is a sans-serif font that resembles the fonts of the Michigan license plates from the 1960's and 1970's. This font is in the public domain and comes with a Euro sign.