GL-Nummernschld-Mtl: Adobe Western 2 character sets

(C)2009-2011 Gutenberg Labo, All rights reserved. http://gutenberg.sourceforge.jp/

"FE-Mittelschrift" designed by Karlgeorg Hoefer.
We refered to "FZV - Anlange 4" (http://bundesrecht.juris.de/fzv/anlage_4_62.html, http://www.stvzo.de/stvzo/fzv/anlange_4.htm)
and image file from Wikipedia Commons  (http://commons.wikimedia.org/wiki/File:FE-Schrift.svg)
Font made by Gutenberg Labo, 2009.

- GL-Nummernschld-Mtl license
  These fonts are free softwares.
  Unlimited permission is granted to use, copy, and distribute it, with or without modification, either commercially and noncommercially.
  THESE FONTS ARE PROVIDED "AS IS" WITHOUT WARRANTY.

- About GL-Nummernschld-Mtl font
  GL-Nummernschld is German vehicle registration plates typeface font. This font has no small letters.
  We made this font refering to "StVO, FZV - Anlange 4", and get the typeface image from Wikipedia, and so on.
  And, you can find numberplate-like forms in unicode area E000 to E02C. Enjoy it! ;)